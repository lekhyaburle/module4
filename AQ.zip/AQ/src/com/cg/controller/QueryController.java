package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.QueryMaster;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	@Autowired
	IQueryService queryService;
	
	@RequestMapping("/show")
	public String showHomePage(){
		return ("index");
	}
	@RequestMapping("/answer")
	public ModelAndView answer(@RequestParam("queryId") int id){
		ModelAndView mv=new ModelAndView();
		List<String> answersBy = new ArrayList<String>();
		answersBy.add("Uma");
		answersBy.add("Rahul");
		answersBy.add("Kavita");
		answersBy.add("Hema");
		QueryMaster queryBean=queryService.viewQuery(id);
		mv.setViewName("answer");
		mv.addObject("queryBean", queryBean);
		mv.addObject("list", answersBy);
		if(queryBean==null){
			mv.setViewName("error");
			mv.addObject("id", id);
			return mv;
		}
		return mv;
	}
	
	@RequestMapping("/updateAnswer")
	public ModelAndView answer(@ModelAttribute("bean") @Valid QueryMaster bean,BindingResult result )
	{
		ModelAndView mv=new ModelAndView();
		if (!result.hasErrors()) {
						
			int queryId=queryService.addSolution(bean);
			mv.setViewName("success");
			mv.addObject("id", queryId);
			
		} else{
			mv.setViewName("answer");
			mv.addObject("queryBean", bean);
			mv.addObject("message1", "Solution field should not kept Blank");
			mv.addObject("message2", "You must select one of the name");
			
			//mv.addObject("solutionGivenBy", result.getFieldError("solutionGivenBy"));
		}
		return mv;
	}
	
	
}
