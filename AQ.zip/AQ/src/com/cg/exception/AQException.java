package com.cg.exception;

public class AQException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1677388946814147752L;

	public AQException() {
		super();
		
	}

	public AQException(String message) {
		super(message);
	
	}

	
}
