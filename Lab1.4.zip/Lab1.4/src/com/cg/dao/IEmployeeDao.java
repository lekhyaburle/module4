package com.cg.dao;

import com.cg.bean.Employee;

public interface IEmployeeDao {
	public Employee getEmployeeById(int id);
}
