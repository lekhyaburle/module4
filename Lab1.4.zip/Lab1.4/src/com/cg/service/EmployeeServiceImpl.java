package com.cg.service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeDao;

public class EmployeeServiceImpl {

	IEmployeeDao employeeDao;
	
	
	
	public IEmployeeDao getEmployeeDao() {
		return employeeDao;
	}



	public void setEmployeeDao(IEmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}



	public Employee getEmployeeById(int id){
			
				
			Employee emp=employeeDao.getEmployeeById(id);
		return emp;
	}

	
	
	
}
