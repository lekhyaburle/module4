package com.cg.controller;

import com.cg.bean.Employee;
import com.cg.service.EmployeeServiceImpl;

public class EmployeeController {

EmployeeServiceImpl employeeService;
	
	
	public EmployeeServiceImpl getEmployeeService() {
		return employeeService;
	}


	public void setEmployeeService(EmployeeServiceImpl employeeService) {
		this.employeeService = employeeService;
	}
	
	public Employee sendEmployee(int id){
		Employee emp=employeeService.getEmployeeById(id);
		return emp;
	}
}
