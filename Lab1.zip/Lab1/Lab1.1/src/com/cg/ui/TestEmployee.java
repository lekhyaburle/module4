package com.cg.ui;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class TestEmployee {
	public static void main(String[] args) {
		
	
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
	
	Employee emp=(Employee) ctx.getBean("employee");
	emp.display();
	ctx.close();
	}
}
