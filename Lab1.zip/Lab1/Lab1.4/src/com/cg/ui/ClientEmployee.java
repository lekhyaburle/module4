package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.service.EmployeeServiceImpl;

public class ClientEmployee {

	public static void main(String[] args) {
		Scanner scInput=new Scanner(System.in);
		System.out.println("Enter id");
		int id=scInput.nextInt();
		scInput.nextLine();
		EmployeeServiceImpl employeeService=new EmployeeServiceImpl();
		Employee emp=employeeService.getEmployeeById(id);
		if(emp==null){
			System.out.println("Invalid Employee Id");
		}
		else
		System.out.println(emp);
		scInput.close();
	}

}
