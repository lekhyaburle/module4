package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Employee;

public class EmployeeDaoImpl implements IEmployeeDao{
	private HashMap<Integer, Employee> empList=new HashMap<>();
	
	public HashMap<Integer, Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empList = empList;
	}


	@Override
	public Employee getEmployeeById(int id) {
		
	
		Employee emp=empList.get(id);
		return emp;
	}

}
