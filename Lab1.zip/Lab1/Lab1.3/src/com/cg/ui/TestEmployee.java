package com.cg.ui;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.SBU;

public class TestEmployee {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		
		SBU sbu=(SBU) ctx.getBean("sbu");
	sbu.Display(sbu);
	ctx.close();
	}
}
