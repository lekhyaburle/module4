package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="trainee_tbl")
public class Trainee {

	@Id
	@Column(name="traineeId")
	private int traineeId;
	@Column(name="traineename",length=15)
	private String traineename;
	@Column(name="traineeDomain",length=15)
	private String traineeDomain;
	@Column(name="traineeLocation",length=15)
	private String traineeLocation;
	public Trainee() {
		super();
	}
	public Trainee(int traineeId, String traineename, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineename = traineename;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineename() {
		return traineename;
	}
	public void setTraineename(String traineename) {
		this.traineename = traineename;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	
	
}
