package com.cg.bean;



public class Trainee {

	private int traineeId;
	private String traineename;
	private String traineeDomain;
	private String traineeLocation;
	public Trainee() {
		super();
	}
	public Trainee(int traineeId, String traineename, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineename = traineename;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineename() {
		return traineename;
	}
	public void setTraineename(String traineename) {
		this.traineename = traineename;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	
	
}
