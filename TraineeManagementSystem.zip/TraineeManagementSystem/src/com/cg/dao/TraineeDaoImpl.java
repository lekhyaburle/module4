package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Trainee;
import com.cg.exception.TraineeException;
@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee bean) {
		
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}

	@Override
	public Trainee deleteTrainee(int id) {
		Trainee bean=entityManager.find(Trainee.class, id);
		entityManager.remove(bean);
		
		return bean;
	}

	@Override
	public Trainee viewTrainee(int id) {
		Trainee bean=entityManager.find(Trainee.class, id);
		return bean;
	}

	@Override
	public List<Trainee> viewAllTrainees() {
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee", Trainee.class);
		
		List<Trainee> list = query.getResultList();
		return  list;
	}

	@Override
	public boolean updateTrainee(Trainee bean) throws TraineeException {
		Trainee trainee;
		boolean isUpdated=false;
		try {
			trainee=entityManager.find(Trainee.class, bean.getTraineeId());
			trainee.setTraineename(bean.getTraineename());
			trainee.setTraineeDomain(bean.getTraineeDomain());
			trainee.setTraineeLocation(bean.getTraineeLocation());
			entityManager.merge(trainee);
			isUpdated=true;
		} catch (Exception e) {
			throw new TraineeException("no such trainee");
		}
		return isUpdated;
	}
	
	
}
