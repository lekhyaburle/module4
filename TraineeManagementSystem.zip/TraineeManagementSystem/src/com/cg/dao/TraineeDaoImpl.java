package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cg.bean.Trainee;
@Repository
public class TraineeDaoImpl implements ITraineeDao{
	
	Map<Integer, Trainee> map=new HashMap<Integer,Trainee>();

	@Override
	public Trainee addTrainee(Trainee bean) {
			
		map.put(bean.getTraineeId(), bean);
		return bean;
	}

	@Override
	public Trainee deleteTrainee(int id) {
		Trainee bean=map.get(id);
				map.remove(id);
		return bean;
	}

	@Override
	public Trainee viewTrainee(int id) {
		Trainee bean=map.get(id);
		return bean;
	}

	@Override
	public List<Trainee> viewAllTrainees() {
		List<Trainee> result = new ArrayList<Trainee>(map.values());
		return  result;
	}
	
	
}
