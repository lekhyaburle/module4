package com.cg.dao;

import java.util.List;

import com.cg.bean.Trainee;
import com.cg.exception.TraineeException;


public interface ITraineeDao {
	
	public Trainee addTrainee(Trainee bean)throws TraineeException;
	public Trainee deleteTrainee(int id)throws TraineeException;
	public Trainee viewTrainee(int id)throws TraineeException;
	public List<Trainee> viewAllTrainees()throws TraineeException;
	public boolean updateTrainee(Trainee bean)throws TraineeException;
}
