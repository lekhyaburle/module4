package com.cg.service;

import java.util.List;

import com.cg.bean.Trainee;

public interface ITraineeService {
	public Trainee addTrainee(Trainee bean);
	public Trainee deleteTrainee(int id);
	public Trainee viewTrainee(int id);
	public List<Trainee> viewAllTrainees();
}
