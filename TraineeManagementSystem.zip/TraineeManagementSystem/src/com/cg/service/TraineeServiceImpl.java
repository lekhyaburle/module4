package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.ITraineeDao;
@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	ITraineeDao traineeDao;
	
	
	
	
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}




	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}




	@Override
	public Trainee addTrainee(Trainee bean) {
		
		return traineeDao.addTrainee(bean);
	}




	@Override
	public Trainee deleteTrainee(int id) {
		
		return traineeDao.deleteTrainee(id);
	}




	@Override
	public Trainee viewTrainee(int id) {
		
		return traineeDao.viewTrainee(id);
	}




	@Override
	public List<Trainee> viewAllTrainees() {
			
		return traineeDao.viewAllTrainees();
	}

}
