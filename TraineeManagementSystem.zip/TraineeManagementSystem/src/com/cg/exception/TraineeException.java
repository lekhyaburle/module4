package com.cg.exception;

public class TraineeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5544251724002039992L;

	public TraineeException() {
		super();
	}

	public TraineeException(String message) {
		super(message);
		
	}

}
