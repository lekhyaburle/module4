package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponentsBuilder;

import com.cg.bean.Trainee;
import com.cg.exception.TraineeException;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	ITraineeService traineeService;	
	
	public ITraineeService getTraineeService() {
		return traineeService;
	}
	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	@RequestMapping("/show")
	public String showHomePage(){
		return ("index");
	}
	@RequestMapping("/add")
	public String add(){
		return "addTrainee";
	}
	@RequestMapping("/delete")
	public String delete(){
		return "delete";
	}
	
	@RequestMapping("/view")
	public String view(){
		return "view";
	}
	@RequestMapping("/update")
	public String update(){
		return "update";
	}
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(@ModelAttribute("trainee")Trainee bean,BindingResult result,Model model){
		ModelAndView mv = new ModelAndView();
		Trainee tbean=new Trainee();
		if(result.hasErrors()){
			model.addAttribute("message", result);
			mv.setViewName("error");
			mv.addObject("message", result);
			return mv;
		}	
		try {
			tbean=traineeService.addTrainee(bean);
			mv.setViewName("success");
			mv.addObject("bean",tbean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("traineeId") int id){
		ModelAndView mv=new ModelAndView();
		Trainee bean=new Trainee();
		try {
			bean=traineeService.deleteTrainee(id);
			mv.setViewName("success");
			mv.addObject("bean",bean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	@RequestMapping(value={"/viewTrainee","/viewTrainee1","/viewTrainee2"})
	public ModelAndView viewTrainee(@RequestParam("traineeId") int id){
		ModelAndView mv=new ModelAndView();
		Trainee bean=new Trainee();
	
		UriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentRequest();
        String requestedValue = builder.buildAndExpand().getPath();	   
     
		try {
			bean=traineeService.viewTrainee(id);	
			 if (requestedValue.equals("/TraineeManagementSystem/viewTrainee.obj"))
				{
			mv.setViewName("view");
				 }
			 else if(requestedValue.equals("/TraineeManagementSystem/viewTrainee2.obj")){
				 mv.setViewName("update");
			 }
			else{
				mv.setViewName("delete");
			}
			mv.addObject("bean",bean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	@RequestMapping("/viewAllTrainees")
	public ModelAndView viewAllTrainees(){
		ModelAndView mv=new ModelAndView();
		try {
			List<Trainee> list=traineeService.viewAllTrainees();
			mv.setViewName("successview");
			mv.addObject("list",list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	@RequestMapping("/updateTrainee")
		public ModelAndView updateTrainee(@ModelAttribute("bean")Trainee bean ){
			ModelAndView mv=new ModelAndView();
			try{
				traineeService.updateTrainee(bean);
				mv.setViewName("success");
				
			}catch(TraineeException e){
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
			return mv;
		}
}
