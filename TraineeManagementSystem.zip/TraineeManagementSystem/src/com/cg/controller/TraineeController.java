package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	ITraineeService traineeService;
	
	
	
	public ITraineeService getTraineeService() {
		return traineeService;
	}
	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	@RequestMapping("/show")
	public String showHomePage(){
		return ("index");
	}
	@RequestMapping("/add")
	public String add(){
		return "addTrainee";
	}
	@RequestMapping("/delete")
	public String delete(){
		return "delete";
	}
	
	@RequestMapping("/view")
	public String view(){
		return "view";
	}
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(@ModelAttribute("trainee")Trainee bean,BindingResult result,Model model){
		ModelAndView mv = new ModelAndView();
		Trainee tbean=new Trainee();
		if(result.hasErrors()){
			model.addAttribute("message", result);
			mv.setViewName("error");
			mv.addObject("message", result);
			return mv;
		}	
		tbean=traineeService.addTrainee(bean);
		mv.setViewName("success");
		mv.addObject("bean",tbean);
		return mv;
	}
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("traineeId") int id){
		ModelAndView mv=new ModelAndView();
		Trainee bean=new Trainee();
		bean=traineeService.deleteTrainee(id);
		mv.setViewName("success");
		mv.addObject("bean",bean);
		return mv;
	}
	@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee(@RequestParam("traineeId") int id){
		ModelAndView mv=new ModelAndView();
		Trainee bean=new Trainee();
		bean=traineeService.deleteTrainee(id);
		mv.setViewName("success");
		mv.addObject("bean",bean);
		return mv;
	}
	@RequestMapping("/viewAllTrainees")
	public ModelAndView viewAllTrainees(){
		ModelAndView mv=new ModelAndView();
		List<Trainee> list=traineeService.viewAllTrainees();
		mv.setViewName("successview");
		mv.addObject("list",list);
		return mv;
	}
		
}
